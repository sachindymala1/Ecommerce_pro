package com.shopiffy.onlineshop.model;

import javax.persistence.*;

@Entity
public class GoogleMapsLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Long latitude;
    private Long longitude;

    @OneToOne
    public User user;

    public GoogleMapsLocation(){

    }

    public GoogleMapsLocation(long latitude, long longitude, User user ){
        this.latitude = latitude;
        this.longitude = longitude;
        this.user = user;
    }
}
